<?php

# When installed via composer
require_once './vendor/autoload.php';
echo '<pre>';
$csv = new Deblan\Csv\Csv();
$csv->setHeaders(['CID', 'NAME', 'POS', 'REF']);
$csv->setDelimiter(",");
$csv->setCharset("UTF-8");
$filename = "aa-".date('YmdHi',strtotime('now')).".csv";
$cid = strtotime('now');
$faker = Faker\Factory::create('en_US');


// Create a file pointer 
$f = __DIR__ . '/files/' . $filename;
$agents = array();
try {
    //$root = strtotime('now');
    $root = 1697884392;
    //$agents[]= array($root, $faker->name, '0', '0');
    
    for ($i = 1,$j=100001; $i <= 25; $i++,$j++) {
        $lcid = $root+$i;
        $rcid = $root+$j;
        $wing = ($i % 2) ? 'L' : 'R';
        
        $agents[] = array(
            $lcid,
            $faker->name,
            'L',
            $root
        );
        $agents[] = array(
            $rcid,
            $faker->name,
            'R',
            $root
        );
        $root = ($i % 2)? $lcid:$rcid;
    }
} catch (Exception $ex) {
    print_r($ex->getMessage());
}
$csv->setDatas($agents);
$result = $csv->render($f);
print_r($result);
echo '</pre>';
