<?php
$foliage_settings = get_option('finance_foliage_settings');
$agentnode_url = get_permalink($foliage_settings['agentnode_single_page_id']);
$finance_report_url = get_permalink($foliage_settings['finance_report_page_id']);
$agentnode_add_url = get_permalink($foliage_settings['agentnode_addnew_page_id']);
$agentnode_edit_url = get_permalink($foliage_settings['agentnode_edit_page_id']);
?>
<div class="row">
    <div class="col-sm-12">
        <div class="card card-info">
            <div class="card-header">


                <div class="card-tools">
                    <a href="<?php echo $agentnode_add_url; ?>"  class="btn btn-tool" >
                        <i class="fas fa-user-plus mr-2"></i> Add new agent
                    </a>
                    |
                    <a href="<?php echo $agentnode_add_url; ?>?import=csv"  class="btn btn-tool" >
                        <i class="fas fa-file-upload mr-2 ml-2" ></i> Import From File
                    </a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="agent-datatable" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th style="width: 20px">#</th>
                            <th style="width: 20px">Agent ID</th>

                            <th style="width: 200px">Name</th>
                            <th style="width: 15px">Left</th>
                            <th style="width: 15px">Total Left</th>
                            <th style="width: 15px">Right</th>
                            <th style="width: 15px">Total Right</th>
                            <th style="width: 15px">Level</th>
                            <th style="width: 15px">Circle</th>
                            <th style="width: 30px">Registered</th>
                            <th style="width: 40px">-</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        global $wpdb;
                        $table_name = $wpdb->prefix . 'alliance';
                        $agents = $wpdb->get_results('SELECT * FROM ' . $table_name . ' ORDER BY ID ASC');

                        if (!empty($agents)):

                            foreach ($agents as $key => $agent):
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo $agent->aid; ?></td>
                                    <td><?php echo $agent->user_name; ?></td>
                                    <td><?php echo $agent->left_node_count ; ?></td>
                                    <td><?php echo $agent->all_node_count_left; ?></td>
                                    <td><?php echo $agent->right_node_count; ?></td>
                                    <td><?php echo $agent->all_node_count_right; ?></td>
                                    <td><?php echo $agent->active_level; ?></td>
                                    <td><?php echo $agent->active_circle; ?></td>
                                    <td><?php echo date("D jS, M Y", $agent->created_at); ?></td>
                                   

                                    <td>
                                        <a href="<?php echo $agentnode_edit_url . '?view=edit&node=' . $agent->ID; ?>" class="btn btn-sm" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?php echo $agentnode_url . '?view=tree&node=' . $agent->ID; ?>" class="btn btn-sm" title="Tree View">
                                            <i class="fas fa-project-diagram"></i>
                                        </a>
                                        <a href="<?php echo $agentnode_url . '?view=info&node=' . $agent->ID; ?>" class="btn btn-sm" title="Ino">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            endforeach;
                        endif;
                        ?>
                    </tbody>

                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
</div>