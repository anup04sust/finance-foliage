'use strict';
(function ($) {
    $(document).ready(function () {
//        if ($('#donutChart').length > 0) {
//            var donutChartCanvas = $('#donutChart').get(0).getContext('2d');
//            var _donutData = {
//                labels: donutData.labels,
//                datasets: [
//                    {
//                        data: donutData.datasets.data,
//                        backgroundColor: donutData.datasets.backgroundColor,
//                    }
//                ]
//            };
//            var donutOptions = {
//                maintainAspectRatio: false,
//                responsive: true,
//            };
//            //Create pie or douhnut chart
//            // You can switch between pie and douhnut using the method below.
//
//            new Chart(donutChartCanvas, {
//                type: 'pie',
//                data: _donutData,
//                options: donutOptions
//            });
//
//
//        }
        //-------------
        //- BAR CHART -
        //-------------
//        if ($('#barChart').length > 0) {
//            console.log(weekDayRegeistered);
//            var areaChartData = {
//                labels: ['Thursdays', 'Fridays', 'Saturdays', 'Sundays', 'Mondays', 'Tuesdays', 'Wednesdays'],
//                datasets: [
//                    {
//                        label: 'Current week',
//                        backgroundColor: 'rgba(60,141,188,0.9)',
//                        borderColor: 'rgba(60,141,188,0.8)',
//                        pointRadius: false,
//                        pointColor: '#3b8bba',
//                        pointStrokeColor: 'rgba(60,141,188,1)',
//                        pointHighlightFill: '#fff',
//                        pointHighlightStroke: 'rgba(60,141,188,1)',
//                        data: weekDayRegeistered.current_week
//                    },
//                    {
//                        label: 'Previous week',
//                        backgroundColor: 'rgba(210, 214, 222, 1)',
//                        borderColor: 'rgba(210, 214, 222, 1)',
//                        pointRadius: false,
//                        pointColor: 'rgba(210, 214, 222, 1)',
//                        pointStrokeColor: '#c1c7d1',
//                        pointHighlightFill: '#fff',
//                        pointHighlightStroke: 'rgba(220,220,220,1)',
//                        data: weekDayRegeistered.prev_week
//                    },
//                ]
//            };
//            var barChartCanvas = $('#barChart').get(0).getContext('2d');
//            var barChartData = $.extend(true, {}, areaChartData);
//            var temp0 = areaChartData.datasets[0];
//            var temp1 = areaChartData.datasets[1];
//            barChartData.datasets[0] = temp1;
//            barChartData.datasets[1] = temp0;
//
//            var barChartOptions = {
//                responsive: true,
//                maintainAspectRatio: false,
//                datasetFill: false
//            };
//
//            new Chart(barChartCanvas, {
//                type: 'bar',
//                data: barChartData,
//                options: barChartOptions
//            });
//        }  
     });
})(jQuery);
