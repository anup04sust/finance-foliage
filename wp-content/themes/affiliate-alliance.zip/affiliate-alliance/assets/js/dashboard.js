'use strict';

(function ($) {

})(jQuery);
