<a href="<?php echo get_home_url(); ?>" class="brand-link">
    <img src="<?php echo get_stylesheet_directory_uri() . '/assets/images/logo.jpg' ?>" alt="Affiliate Alliance Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light"><strong>affiliate</strong>Alliance</span>
</a>